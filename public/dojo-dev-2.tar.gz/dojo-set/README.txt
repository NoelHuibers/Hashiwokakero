A benchmark set of the Hashi SAT Dojo (https://hashi.rs/dojo).

seed: hashi-dojo-dev-2
commitment: 101fb984c2155362320d3021817d721677adc096456e378946f369915e3bcf04
kind: dev
generator: 2
formulas: 36
budget: 10000000000

Families (formulas, SAT/UNSAT, the family in the Global Benchmark Database):
    hashi           4  4/0  puzzle
    hashi-parity    4  0/4  puzzle
    random-3sat     4  2/2  random
    pigeonhole      4  1/3  pigeon-hole
    queens          3  3/0  puzzle
    factoring       6  3/3  prime-factoring
    miter           5  2/3  miter
    coloring        6  3/3  coloring

One DIMACS CNF file per formula. answers.txt has the expected answer of each, witnesses.txt a
model of every satisfiable one. Every UNSAT label is backed by a proof or by construction.

The commitment is the SHA-256 of the seed. Check it:
    printf %s hashi-dojo-dev-2 | sha256sum
Regenerate the formulas from the seed (with a dojo tool of the same generator version):
    dojo export regenerated/ --seed hashi-dojo-dev-2
Score a solver on exactly these formulas, the way the leaderboard did:
    dojo run my-solver.wasm --set <this .tar.gz>
