The development set of the Hashi SAT Dojo (https://hashi.rs/dojo).

One DIMACS CNF file per formula, answers.txt has the expected answer of each. The hidden test
set of a season has the same families and sizes, generated from a secret seed.

Score a solver exactly like the leaderboard does:
    dojo run my-solver.wasm
Regenerate this set:
    dojo export dojo-dev-1
